import game_framework
import logo_state
from pico2d import *

open_canvas()
game_framework.run(logo_state)
close_canvas()